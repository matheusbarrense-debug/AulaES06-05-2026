from datetime import datetime
from repository import SessaoRepository
from service import SessaoService
from controller import CinemaController

# Bootstrap da aplicação
repo = SessaoRepository()
service = SessaoService(repo)
controller = CinemaController(service)

def menu():
    print("\n--- SISTEMA DE GESTÃO DE CINEMA ---")
    print("1. Agendar Nova Sessão")
    print("2. Sair")
    return input("Escolha uma opção: ")

while True:
    opcao = menu()
    
    if opcao == "1":
        print("\nPreencha os dados da sessão:")
        f_id = int(input("ID do Filme: "))
        s_id = int(input("ID da Sala: "))
        data_hora = input("Data/Hora (DD/MM/AAAA HH:MM): ")
        duracao = int(input("Duração do Filme (minutos): "))
        
        mensagem = controller.criar_sessao(f_id, s_id, data_hora, duracao)
        print(f"\n>>> {mensagem}")
        
    elif opcao == "2":
        break