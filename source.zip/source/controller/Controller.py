class CinemaController:
    def __init__(self, service):
        self.service = service

    def criar_sessao(self, filme_id, sala_id, inicio_str, duracao):
        try:
            # Converte string para objeto datetime
            inicio = datetime.strptime(inicio_str, "%d/%m/%Y %H:%M")
            from models import Sessao
            nova_sessao = Sessao(None, filme_id, sala_id, inicio, duracao)
            
            resultado = self.service.agendar_sessao(nova_sessao)
            return f"Sucesso! Sessão {resultado.id} agendada."
        except ValueError as e:
            return f"Erro de Validação: {str(e)}"
        except Exception as e:
            return f"Erro Crítico: {str(e)}"