# repository.py
class SessaoRepository:
    def __init__(self):
        self._sessoes = []  # Simulando banco de dados em memória
        self._proximo_id = 1

    def salvar(self, sessao):
        sessao.id = self._proximo_id
        self._sessoes.append(sessao)
        self._proximo_id += 1
        return sessao

    def listar_por_sala(self, id_sala):
        return [s for s in self._sessoes if s.id_sala == id_sala]