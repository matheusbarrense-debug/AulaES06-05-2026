
from datetime import timedelta

class SessaoService:
    def __init__(self, repository):
        self.repository = repository

    def agendar_sessao(self, sessao):
        # RN02: Intervalo obrigatório de 20 minutos
        INTERVALO = timedelta(minutes=20)
        sessoes_existentes = self.repository.listar_por_sala(sessao.id_sala)

        for s in sessoes_existentes:
            # Verifica sobreposição considerando o intervalo de limpeza
            inicio_nova = sessao.horario_inicio
            fim_nova = sessao.horario_fim + INTERVALO
            
            inicio_existente = s.horario_inicio
            fim_existente = s.horario_fim + INTERVALO

            if (inicio_nova < fim_existente) and (fim_nova > inicio_existente):
                raise ValueError("Conflito: A sala estará ocupada ou em limpeza neste horário.")

        return self.repository.salvar(sessao)