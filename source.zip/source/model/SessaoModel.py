
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class Sessao:
    id: int
    id_filme: int
    id_sala: int
    horario_inicio: datetime
    duracao_filme: int  # em minutos
    publico: int = 0

    @property
    def horario_fim(self):
        return self.horario_inicio + timedelta(minutes=self.duracao_filme)